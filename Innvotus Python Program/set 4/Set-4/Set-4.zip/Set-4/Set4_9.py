x=5
print(x)
x=-x
print(x)
x=-x
print(x)