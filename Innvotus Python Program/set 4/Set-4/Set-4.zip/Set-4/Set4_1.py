d={}
d[1]="Pune-Mumbai"
d[2]="Pune-Kolhapur"
d[3]="Pune-Nashik"
print(d)