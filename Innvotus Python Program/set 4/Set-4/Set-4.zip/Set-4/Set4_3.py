a,b,c,d=10,12,30,2
print(a>b)
print(c>=d)
print(a<b)
print(b>d)
print(a==d)
print(c!=d)