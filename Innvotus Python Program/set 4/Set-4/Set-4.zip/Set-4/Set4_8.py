s={10,20,30,40,50}
x=frozenset(s)
print(x)