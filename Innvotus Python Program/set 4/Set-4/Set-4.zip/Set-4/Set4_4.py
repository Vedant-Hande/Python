a,b,c,d=10,20,1,5
print((a>b)and(a>c))
print((b>d)or(c<a))
print(not(a<b))