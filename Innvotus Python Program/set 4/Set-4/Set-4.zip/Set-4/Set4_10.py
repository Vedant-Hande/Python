a,b=5,6
c=a>>1
print(c)
x=b<<1
print(x)