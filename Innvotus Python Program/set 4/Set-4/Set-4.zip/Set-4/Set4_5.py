a,b=5,6
k=a&b
print(k)
t=a|b
print(t)
m=a^b
print(m)