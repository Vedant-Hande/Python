names=["Pranav","Sahil","Arpit","Shubham","Vedant","Omkar","Sarthak"]
for name in names:
    print(name)