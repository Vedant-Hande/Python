s=input("Enter the integer::\n")
x=int(s)
print("Integer is::",x)