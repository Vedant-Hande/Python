x,y,z=[int(x) for x in input("Enter 3 integer::").split()]
avg=(x+y+z)/3
print("Aveage is::",avg)