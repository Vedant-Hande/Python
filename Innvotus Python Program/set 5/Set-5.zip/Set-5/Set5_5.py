li=eval(input("Enter the list::"))
print("List is::",li)