x=int(input("Enter first number::"))
y=int(input("Enter Second number::"))
z=int(input("Enter Third number::"))
avg=(x+y+z)/3
print("Average::",avg)