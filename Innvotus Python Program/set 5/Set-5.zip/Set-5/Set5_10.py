s=input("Enter float number::\n")
x=float(s)
print("Float number is::",x)