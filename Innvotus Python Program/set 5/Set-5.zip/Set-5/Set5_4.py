x=eval(input("Enter exprestion::"))

print("Result is::",x)