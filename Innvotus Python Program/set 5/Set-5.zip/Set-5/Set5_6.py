tp=eval(input("Enter the tuple::"))
print("Tuple is::",tp)