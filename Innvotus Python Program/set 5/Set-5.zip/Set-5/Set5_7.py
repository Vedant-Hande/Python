a,b,c,d,e=10,20,30,40,50
print(a,b,c,d,e,sep=(","))