print("Enter the String::")
s=input()
print("String is::",s)