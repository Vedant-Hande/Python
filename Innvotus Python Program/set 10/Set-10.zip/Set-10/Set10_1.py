i=1
n=5
fact=1
while i<=n:
    fact=fact*i
    i+=1
print("Factorial No::",fact)