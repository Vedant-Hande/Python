i,n,sum=1,5,0
while i<=n:
    sum=sum+i
    i+=1
print("SUM=",sum)