import array as  arr
a=arr.array('i',[10,20,30,40,50])
print("Complete array:",a)
print("Individual Array Elements:")
for i in a:
    print(i)

fl=arr.array('f', [10.1,20.1,30.1,22.22])
print("Complete Float array : ",fl)
print("Individual Float array elements are")
for i in fl:
    print(i)
