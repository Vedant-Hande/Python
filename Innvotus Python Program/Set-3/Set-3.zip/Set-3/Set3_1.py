x=[10,20,30,50,40]
k=bytes(x)
for i in x:
    print(i)
