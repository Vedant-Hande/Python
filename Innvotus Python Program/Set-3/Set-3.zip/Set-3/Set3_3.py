x=[1,12.3,"Pranav"]
print(x)
for i in x:
    print(i)