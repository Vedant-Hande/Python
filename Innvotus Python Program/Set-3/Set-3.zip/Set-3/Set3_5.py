x=range(30,50,2)
for i in x:
    print(i)