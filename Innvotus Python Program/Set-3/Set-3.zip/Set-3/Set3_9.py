x=range(10,50)
v=list(x)
for i in v:
    print(i)