ele=[10,20,30,40,50]
x=set(ele)
print(x)
x.update([40,100])
print(x)
x.remove(30)
print(x)