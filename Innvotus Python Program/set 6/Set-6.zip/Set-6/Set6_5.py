x=int(input("Enter the number between 0 to 9::"))
if(x>=0 and x<=9):
    if x==0:
        print("ZERO")
    elif x==1:
        print("ONE")
    elif x==2:
        print("TWO")
    elif x==3:
        print("THREE")
    elif x==4:
        print("FOURE")
    elif x==5:
        print("FIVE")
    elif x==6:
        print("SIX")
    elif x==7:
        print("SEVEN")
    elif x==8:
        print("EIGHT")
    elif x==9:
        print("NINE")
else:
    print("Number is not in betweem 0 to 9")
        
        
