x=int(input("Enter the first number::"))
if(x%2==0):
    print("The number is even:",x)
else:
    print("The number is odd:",x)
    