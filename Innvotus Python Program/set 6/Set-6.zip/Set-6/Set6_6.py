x=int(input("Enter the number::"))
if(x>=55 and x<=98):
    print("Number is in the range::",x)
else:
    print("Number is not in the range::",x)