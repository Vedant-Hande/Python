x=int(input("Enter the number::"))
if(x%5==0 and x%9==0):
    print("Number is divides by 5 and 9::",x)
else:
    print("Number is not divides by 5 and 9::",x)