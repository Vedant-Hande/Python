x=int(input("Enter the number::"))
y=int(input("Enter the number::"))
big=0
if(x>y):
    big=x
else:
    big=y
print("Biggest Number is::",big)
    
