year=int(input("Enter the year::\n"))
if(year%4==0):
    print("Year is a leap:",year)
else:
    print("Year is not leap:",year)