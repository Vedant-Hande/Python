x=int(input("Enter the first number::"))
y=int(input("Enter the second number::"))

if(y!=0):
    z=x/y
    print("Division is:",z)
else:
    print("Infinity")