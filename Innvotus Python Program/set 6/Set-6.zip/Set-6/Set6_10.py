num=int(input("Enter the number::"))
if(num>0):
    print("Number is a positive:",num)
else:
    print("Number is a negative:",num)