x=[2000,2024,2025,2014,2017,2019]
count=0
for ele in x:
    if(ele%4==0):
        count=count+1
print("Number of leap year's are::",count)
    