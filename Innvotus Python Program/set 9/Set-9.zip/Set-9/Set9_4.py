n=20
for i in range(1,n+1):
    print(i)
    if(i%3==0):
        print("-----------------------------------")