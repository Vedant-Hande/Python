name = input("Enter your name: ")
N = int(input("Enter the number of times to print your name: "))

for i in range(N):
    print(name)
