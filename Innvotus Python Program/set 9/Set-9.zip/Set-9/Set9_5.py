x=[10,20,30,40,50,60]
count=0
for ele in x:
    if(ele%2==0):
        count=count+1
print("number of Even Number are::",count)
    