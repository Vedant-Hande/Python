n=15
f1,f2=-1,1
for i in range(1,n+1):
    f3=f1+f2
    print(f3)
    f1=f2
    f2=f3