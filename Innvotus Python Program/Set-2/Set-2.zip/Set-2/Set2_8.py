mm=300
meters = mm / 1000.0
centimeters = mm / 10.0
millimeters = mm
inches = mm / 25.4
feet = inches / 12.0

print("Meters=",meters)
print("Feets=",feet)
print("Inches=",inches)
print("Centimeter=",centimeters)
print("Millimeter=",millimeters)
   
   