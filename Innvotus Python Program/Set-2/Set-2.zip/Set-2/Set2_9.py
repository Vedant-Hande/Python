b,h=10,20
area=(1/2)*(b*h)
print("Area=",area)