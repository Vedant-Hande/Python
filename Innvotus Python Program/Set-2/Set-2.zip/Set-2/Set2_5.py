import math
a,b,x,y=2,6,3,8

p1=(a+b)/(x+y)
p2=1/(x+y)
result=math.pow(p1,p2)
print("Result is=",result)