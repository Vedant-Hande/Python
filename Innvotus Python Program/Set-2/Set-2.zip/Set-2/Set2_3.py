import math
a,b,c=2,3,4
s=(a+b+c)/2
v=s*(s-a)*(s-b)*(s-c)
a=math.sqrt(v)
print("Aera=",a)