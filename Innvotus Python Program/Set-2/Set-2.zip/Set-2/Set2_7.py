import math
b,c,A,B=4,-2,8,2
v1=(b*b)/abs(c)
v2=math.sqrt(3)*A*A
v3=math.sqrt(8+B)
R=v1+v2+v3
print("Result=",R)