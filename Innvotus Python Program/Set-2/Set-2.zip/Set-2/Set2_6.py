import math
m,n,p,x,y,a,b,c=0,2,7,6,4,0,1,2
v1=math.sqrt(m+n+p)
hr=math.pow(v1,(x+y))
dr=(a+b+c)/(m+n)
r=hr/dr
print("Result is=",r)