P,R,T=1000,10,2
SI=(P*R*T)/100
print("Simple Interest=",SI)