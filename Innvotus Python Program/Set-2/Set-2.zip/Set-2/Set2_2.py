import math
x1,y1,x2,y2=2,3,4,1
v1=math.pow((x1-x2),2)
v2=math.pow((y1-y2),2)
s=v1+v2
ed=math.sqrt(s)
print("Distance is=",ed)