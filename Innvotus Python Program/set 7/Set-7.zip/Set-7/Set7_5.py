x=int(input("Enter the number::"))
if(x>=0 and x<=35):
    print("FAIL")
elif(x>=36 and x<=40):
    print("PASS CLASS")
elif(x>=41 and x<=50):
    print("3rd DIVISION")
elif(x>=51 and x<=60):
    print("2nd DIVISION")
elif(x>=61 and x<=70):
    print("1st DIVISION")
elif(x>=71 and x<=100):
    print("DISTINCTION")
else:
    print("INVALID MARK'S")