x=int(input("Enter the Color ::"))
if x==1:
    print("Violet")
elif x==2:
    print("Indigo")
elif x==3:
    print("Blue")
elif x==4:
    print("Green")
elif x==5:
    print("Yellow")
elif x==6:
    print("Orange")
elif x==7:
    print("Red")
else:
    print("Invalid")
