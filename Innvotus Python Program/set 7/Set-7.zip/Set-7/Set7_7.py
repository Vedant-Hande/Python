x=int(input("Enter the Week::"))
if x==1:
    print("Sunday")
elif x==2:
    print("Monday")
elif x==3:
    print("Tuesday")
elif x==4:
    print("Wednesday")
elif x==5:
    print("Thursday")
elif x==6:
    print("Friday")
elif x==7:
    print("Saturday")
else:
    print("Invalid")
