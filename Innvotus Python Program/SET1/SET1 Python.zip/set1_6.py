# 6. Write a Program to find the sum of two Complex Numbers
a,b= 3+2j, 6+4j;
Sum_complex_num = (a+b)
print("Sum_complex_num : ",Sum_complex_num)

# ANS: Sum_complex_num :  (9+6j)