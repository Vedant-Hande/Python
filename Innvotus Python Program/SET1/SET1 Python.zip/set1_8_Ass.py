# 8. Write a program to print “Hello World” using single and three Single Quotes

print('Hello World')
print("""Hello World""")

# Ans : Hello World
#       Hello World 