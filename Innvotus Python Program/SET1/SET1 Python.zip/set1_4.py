# 4. Write a program to swap two integers & display the result before swapping & after wapping (hint: use third variable)

a = 10 
b = 20
print("before swapping a =",a," before swapping b =",b )
temp = a
a = b 
b = temp 
print("After swapping a =",a," After swapping b =",b )

# ANS - before swapping a = 10  before swapping b = 20
#       After swapping a = 20  After swapping b = 10 