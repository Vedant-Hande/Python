# 2. Write a program to find division of two integers using type casting to float.

num1 = 10
num2 = 4
result = float(num1/num2)
print("division of two integers -",result)

# ANS - division of two integers - 2.5 