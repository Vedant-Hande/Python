# 9. Write a program to find Addition of two integers.

Number1= 100
Number2= 200
print("The Addation of Number1 & Number2 is = ",(Number1+Number2))

# Ans : The Addation of Number1 & Number2 is =  300