# 3. Write a program to find the remainder of two integers

n1 = 6
n2 = 3
print("remainder of two integers:", n1%n2)

# ANS- remainder of two integers: 0 