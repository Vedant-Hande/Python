# 1. Write a program to print “Hello World” using single and three Double Quotes

print('Hello World')
print("""Hello world""")

# ANS- Hello World
#      Hello world