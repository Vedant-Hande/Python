# 7. Write a Program to convert number of items into Dozens and remaining unit
noi= 57;
Dozens= (int)(noi/12)
units= noi%12
print("Dozens : ",Dozens,"Units : ",units)

# noi= 57
# noi/12= 0
# noi%2 = 7
# ANS= Dozens :  4 Units :  9
