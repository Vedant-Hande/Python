# 5. Write a program to swap two integers without using third variable & display the result 
# before swapping & after swapping.

a = 10 
b = 20
print("before swapping a =",a," before swapping b =",b )
a= a+b 
b=a-b
a= a-b
print("After swapping a =",a," After swapping b =",b )

# ANS - before swapping a = 10  before swapping b = 20
#       After swapping a = 20  After swapping b = 10 