a=372
b=853
for i in range(371,853):
    if(i%2==0):
        print(i)