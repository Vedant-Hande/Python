n=25
for i in range(1,n,2):
    print(i)
