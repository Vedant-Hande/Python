a=567
b=134
for i in range(a,b-1,-1):
    if(i%9==0 and i%6!=0):
        print(i)