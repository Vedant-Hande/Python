n=10
for i in range(n,0,-1):
    print(i)
    
