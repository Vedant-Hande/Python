s="INDIA"
for i in s:
    print(i)