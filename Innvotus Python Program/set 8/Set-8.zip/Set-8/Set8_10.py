n=5
sum=0
for i in range(1,n+1):
    sum=sum+i
    
print("Sum is ::",sum)